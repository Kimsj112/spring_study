{
    let $writeBtn = document.querySelector('.add-post-btn');

    $writeBtn.addEventListener('click', function () {
        location.href = '/board/write';
    });
}